 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title'); ?>
<?php if(isset($book)): ?>
    Biblios :: Edit Book
<?php else: ?>
    Biblios :: Add new book
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Library</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Books</a></li>
<?php if(isset($book)): ?>
    <li class="breadcrumb-item active" aria-current="page">Edit book</li>
<?php else: ?>
    <li class="breadcrumb-item active" aria-current="page">Add book</li>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<script>
    $(document).ready(function() {
        $("form[name='book']").submit(function(event){
            var title = $("input[name='title']").val();
            var error = false;
            // Verifica se almeno una categoria è stata selezionata
            if($("select[name='categories[]'] option:selected").length === 0)
            {
                error = true;
                $("#invalid-category").text("Selezionare almeno una categoria");
                event.preventDefault(); // Impedisce l'invio del modulo
                $("select[name='categories[]']").focus();
            } else {
                $("#invalid-category").text("");
            }

            // Verifica se il campo "title" è vuoto
            if($("input[name='title']").val().trim() === "")
            {
                error = true;
                $("#invalid-title").text("Il titolo del libro è obbligatorio");
                event.preventDefault(); // Impedisce l'invio del modulo
                $("input[name='title']").focus();
            } else {
                $("#invalid-title").text("");
            }

            if(!error)
            {
                // effettua chiamata AJAX per verificare che il titolo del libro non sia presente nel DB
                var metodoHttp = $("input[name='_method']").val();
                if(metodoHttp === undefined) // stiamo creando un nuovo libro
                {
                    event.preventDefault();
                    $.ajax({
                        type: 'GET',
                        url: '/ajaxBook',
                        data: {title: title.trim()},
                        success: function(data) {
                            if(data.found)
                            {
                                error = true;
                                $("#invalid-title").text("Un libro con questo titolo è già presente nel database");
                            } else {
                                $("form[name='book']")[0].submit();
                            }
                        }
                    });
                }
            }
        });
    });
</script>
<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php if(isset($book)): ?>
                <form class="form-horizontal" name="book" method="post" action="<?php echo e(route('book.update', ['book' => $book->id])); ?>">
                <!--<input type="hidden" name="_method" value="PUT">-->
                <?php echo method_field('PUT'); ?>
                <?php else: ?>
                <form class="form-horizontal" name="book" method="post" action="<?php echo e(route('book.store')); ?>">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="categories">Categories</label>
                        </div>
                        <div class="col-md-10">
                            <select class="form-control" multiple="multiple" name="categories[]">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if((isset($book->id))&&($book->categories->contains($cat))): ?>
                                    <option value="<?php echo e($cat->id); ?>" selected="selected"><?php echo e($cat->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
                            </select>
                            <span class="invalid-input" id="invalid-category"></span>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="title">Title</label>
                        </div>
                        <div class="col-md-10">
                            <?php if(isset($book)): ?>
                                <input class="form-control" type="text" name="title" value="<?php echo e($book->title); ?>"/>
                            <?php else: ?>
                                <input class="form-control" type="text" name="title"/>
                            <?php endif; ?>
                            <span class="invalid-input" id="invalid-title"></span>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="author_id">Author</label>
                        </div>
                        <div class="col-md-10">
                            <select class="form-control" name="author_id">
                                <?php $__currentLoopData = $authorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if((isset($book))&&($author->id == $book->author_id)): ?>
                                        <option value="<?php echo e($author->id); ?>" selected="selected"><?php echo e($author->lastname); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($author->id); ?>"><?php echo e($author->lastname); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-10 offset-md-2">
                            <?php if(isset($book)): ?>
                                <label for="mySubmit" class="btn btn-primary w-100"><i class="bi bi-floppy2-fill"></i> Save</label>
                                <input id="mySubmit" class="d-none" type="submit" value="Save"/>
                            <?php else: ?>
                                <label for="mySubmit" class="btn btn-primary w-100"><i class="bi bi-floppy2-fill"></i> Create</label>
                                <input id="mySubmit" class="d-none" type="submit" value="Create"/>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-10 offset-md-2">
                            <a class="btn btn-danger w-100" href="<?php echo e(route('book.index')); ?>"><i class="bi bi-box-arrow-left"></i>
                                Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samue\Desktop\WEB_programmazione\tde_svolti\06_Carica_pdf\studio_autenticazione\resources\views/book/editBook.blade.php ENDPATH**/ ?>