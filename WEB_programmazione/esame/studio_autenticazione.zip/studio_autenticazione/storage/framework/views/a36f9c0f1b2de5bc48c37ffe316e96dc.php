 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', 'Biblios :: Book details'); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Library</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Books</a></li>
<li class="breadcrumb-item active" aria-current="page"><?php echo e($book->title); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-md-10">
        <div class="row mb-3">
            <div class="col-md-3">
                <b>Title:</b>
            </div>
            <div class="col-md-9">
                <?php echo e($book->title); ?>

            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-3">
                <b>Author:</b>
            </div>
            <div class="col-md-9">
                <?php echo e($book->author->lastname); ?>, <?php echo e($book->author->firstname); ?>

            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-3">
                <b>Categories:</b>
            </div>
            <div class="col-md-8">
            <?php $__currentLoopData = $book->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($cat->name); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    
            </div>
        </div>
    </div>

    <div class="col-md-2">
        <div class="row mb-3">
            <div class="col-md-12">
                <a class="btn btn-primary w-100" href="<?php echo e(route('book.edit', ['book' => $book->id])); ?>"><i class="bi bi-pencil-square"></i> Edit</a>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <a class="btn btn-danger w-100" href="<?php echo e(route('book.destroy.confirm', ['id' => $book->id])); ?>"><i class="bi bi-trash"></i> Delete</a>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <a class="btn btn-secondary w-100" href="<?php echo e(route('book.index')); ?>"><i class="bi bi-box-arrow-left"></i> Back</a>
    </div>
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samue\Desktop\WEB_programmazione\tde_svolti\06_Carica_pdf\studio_autenticazione\resources\views/book/details.blade.php ENDPATH**/ ?>