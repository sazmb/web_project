<?php $__env->startSection('title', "HotelExplorer :: <?php echo e($hotel->name ?? 'Hotel details'); ?>"); ?>

<?php $__env->startSection('active_Hotels','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item"><a href="<?php echo e(route('hotel.index')); ?>">Hotels</a></li>
<li class="breadcrumb-item active" aria-current="page"><?php echo e($hotel->name ?? 'Hotel details'); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="container mt-4">
    <h2><?php echo e($hotel->name ?? 'Hotel name not available'); ?></h2>
    <p><strong>Location:</strong> <?php echo e($hotel->location ?? 'Location not available'); ?></p>
    <p><strong>Description:</strong> <?php echo e($hotel->description ?? 'No description available.'); ?></p>

    <hr>

    <h4>Reviews (<?php echo e($reviews->count()); ?>)</h4>

    <?php if($reviews->isEmpty()): ?>
        <p>No reviews yet for this hotel.</p>
    <?php else: ?>
        <ul class="list-group mb-4">
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <strong><?php echo e($review->user->name ?? 'Unknown user'); ?></strong> 
                    <span class="text-muted">(<?php echo e($review->data ? \Carbon\Carbon::parse($review->data)->format('d/m/Y') : ''); ?>)</span>
                    <br>
                    <strong>Score:</strong> <?php echo e($review->punteggio); ?>/5<br>
                    <em><?php echo e($review->commento); ?></em>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'registered_user'): ?>
        <div id="reviewFormContainer">
            <h5>Add Your Review</h5>
            <form id="reviewForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="hotel_id" value="<?php echo e($hotel->id); ?>">

                <div class="mb-3">
                    <label for="punteggio" class="form-label">Score (1-5):</label>
                    <select name="punteggio" id="punteggio" class="form-select" required>
                        <option value="" selected disabled>Select score</option>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="commento" class="form-label">Comment:</label>
                    <textarea name="commento" id="commento" rows="3" class="form-control" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Submit Review</button>
            </form>
        </div>

        <div id="message" class="mt-3"></div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
$(document).ready(function() {
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role === 'registeredUser'): ?>
        $.ajax({
            url: "<?php echo e(route('ajaxCheckReview')); ?>",
            method: "POST",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                hotel_id: "<?php echo e($hotel->id); ?>"
            },
            success: function(response) {
                if(response.alreadyReviewed) {
                    $("#reviewFormContainer").hide();
                    $("#message").html('<div class="alert alert-warning">You have already submitted a review for this hotel. Multiple reviews are not allowed.</div>');
                }
            },
            error: function() {
                console.error('Error checking review status.');
            }
        });

        $("#reviewForm").submit(function(e) {
            e.preventDefault();
            $("#message").html('');

            $.ajax({
                url: "<?php echo e(route('review.store')); ?>",
                method: "POST",
                data: $(this).serialize(),
                success: function(data) {
                    $("#message").html('<div class="alert alert-success">Review submitted successfully!</div>');
                    $("#reviewForm")[0].reset();
                    location.reload();
                },
                error: function(xhr) {
                    let errors = xhr.responseJSON?.errors;
                    let errorMessages = '';
                    if(errors) {
                        Object.values(errors).forEach(arr => {
                            arr.forEach(msg => errorMessages += `<p>${msg}</p>`);
                        });
                    } else {
                        errorMessages = 'An error occurred while submitting the review.';
                    }
                    $("#message").html('<div class="alert alert-danger">'+errorMessages+'</div>');
                }
            });
        });
        <?php endif; ?>
    <?php endif; ?>
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samue\Desktop\esame\studio_autenticazione\resources\views/review/reviews.blade.php ENDPATH**/ ?>