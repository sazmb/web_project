<!DOCTYPE html>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, 
              user-scalable=no">

        <!-- Fogli di stile -->
        <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/bootstrap.min.css">
        <link href="<?php echo e(url('/')); ?>/css/style.css" rel="stylesheet">

        <!-- jQuery e plugin JavaScript  -->
        <script src="http://code.jquery.com/jquery.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
        <script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>

        <!-- Custom jQuery and Javascript scripts -->
        <script src="<?php echo e(url('/')); ?>/js/paginationScript.js"></script>

        <!-- Bootstrap Icons -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">Biblios</a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $__env->yieldContent('active_home'); ?>" aria-current="page" href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <?php if(auth()->check()): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?php echo $__env->yieldContent('active_MyLibrary'); ?>" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo app('translator')->get('messages.my_library'); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('book.index')); ?>"><?php echo e(trans('messages.books_list')); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('author.index')); ?>"><?php echo e(trans('messages.authors_list')); ?></a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item"><a href="<?php echo e(route('setLang', ['lang' => 'en'])); ?>" class="nav-link"><img src="<?php echo e(url('/')); ?>/img/flags/en.png" width="20"/></a></li>
                    <li class="nav-item"><a href="<?php echo e(route('setLang', ['lang' => 'it'])); ?>" class="nav-link"><img src="<?php echo e(url('/')); ?>/img/flags/it.png" width="16"/></a></li>
                </ul>
                <ul class="navbar-nav">
                    <?php if(auth()->check()): ?>
                    <li class="nav-item"><i><?php echo e(trans('messages.welcome')); ?> <?php echo e(auth()->user()->name); ?></i>
                        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
                        <?php echo csrf_field(); ?>
                            <button type="submit" style="background: none; border: none; padding: 0; cursor: pointer;">
                                <i class="bi bi-box-arrow-right"></i>
                            </button>
                        </form>
                    </li>
                    <?php else: ?>
                    <li class="nav-item"><a href="<?php echo e(route('login')); ?>"><i class="bi bi-person-lock"></i></a></li>
                    <?php endif; ?>
                </ul>
              </div>
            </div>
        </nav>

        <div class="container-fluid d-flex justify-content-end">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </ol>
            </nav>
        </div>
        
        <div class="container-fluid">
            <header class="header-sezione">
                <h1>
                    <?php echo $__env->yieldContent('title'); ?>
                </h1>
            </header>
        </div>

        <?php echo $__env->yieldContent('body'); ?>
    </body>
</html><?php /**PATH C:\Users\samue\Desktop\WEB_programmazione\versioni\PW_runningExample_v9_internazionalizzazione\resources\views/layouts/master.blade.php ENDPATH**/ ?>