 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Wrong ID Error</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="container-fluid text-center">
    <div class="row">
        <div class="col-md-12">
            <div class="card border-danger">
                <div class='card-header'>
                    <b>Illegal page access:</b> something <strong>wrong</strong> happened while accessing this page!
                </div>
                <div class='card-body'>
                    <p><?php echo e($message); ?></p>
                    <p><a class="btn btn-danger" href="<?php echo e(route('home')); ?>"><i class="bi bi-box-arrow-left"></i> Back to home!</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samue\Desktop\WEB_programmazione\tde_svolti\06_Carica_pdf\studio_autenticazione\resources\views/errors/wrongID.blade.php ENDPATH**/ ?>