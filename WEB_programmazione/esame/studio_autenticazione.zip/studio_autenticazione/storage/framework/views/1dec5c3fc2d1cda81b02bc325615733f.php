 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Library</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Books</a></li>
<li class="breadcrumb-item active" aria-current="page">Delete book</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="container-fluid text-center">
    <div class="row">
        <div class="col-md-12">
            <header>
                <h1>
                    Delete book "<?php echo e($book->getTitle()); ?>" from the list
                </h1>
            </header>
            <p class="confirm">
                Deleting book. Confirm?
            </p>
        </div>
    </div>
</div>

<div class="container-fluid text-center">
    <div class="row">
        <div class="col-md-6 order-md-2">
            <div class="card border-secondary">
                <div class="card-header">
                    Confirm
                </div>
                <div class="card-body">
                    <p>
                        The book <strong>will be permanently removed</strong> from the data base
                    </p>
                    <form name="book.delete" method="post" action="<?php echo e(route('book.destroy', ['book' => $book->getId()])); ?>">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <label for="mySubmit" class="btn btn-danger"><i class="bi bi-trash"></i> Delete</label>
                        <input id="mySubmit" class="d-none" type="submit" value="Delete">
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-6 order-md-1">
            <div class="card border-secondary">
                <div class="card-header">
                    Revert
                </div>
                <div class="card-body">
                    <p>
                        The book <strong>will not be removed</strong> from the data base
                    </p>
                    <a class="btn btn-secondary" href="<?php echo e(route('book.index')); ?>"><i class="bi bi-box-arrow-left"></i> Cancel</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v5_Laravel/resources/views/book/deleteBook.blade.php ENDPATH**/ ?>