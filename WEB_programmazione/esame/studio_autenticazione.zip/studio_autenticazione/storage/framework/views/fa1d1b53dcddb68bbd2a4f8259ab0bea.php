 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title'); ?>
<?php if(isset($book)): ?>
    Biblios :: Edit Book
<?php else: ?>
    Biblios :: Add new book
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Library</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('book.index')); ?>">Books</a></li>
<?php if(isset($book)): ?>
    <li class="breadcrumb-item active" aria-current="page">Edit book</li>
<?php else: ?>
    <li class="breadcrumb-item active" aria-current="page">Add book</li>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php if(isset($book)): ?>
                <form class="form-horizontal" name="book" method="post" action="<?php echo e(route('book.update', ['book' => $book->getId()])); ?>">
                <!--<input type="hidden" name="_method" value="PUT">-->
                <?php echo method_field('PUT'); ?>
                <?php else: ?>
                <form class="form-horizontal" name="book" method="post" action="<?php echo e(route('book.store')); ?>">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="title">Title</label>
                        </div>
                        <div class="col-md-10">
                            <?php if(isset($book)): ?>
                                <input class="form-control" type="text" name="title" value="<?php echo e($book->getTitle()); ?>"/>
                            <?php else: ?>
                                <input class="form-control" type="text" name="title"/>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="author_id">Author</label>
                        </div>
                        <div class="col-md-10">
                            <select class="form-control" name="author_id">
                                <?php $__currentLoopData = $authorList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if((isset($book))&&($author->getId() == $book->getAuthorID())): ?>
                                        <option value="<?php echo e($author->getId()); ?>" selected="selected"><?php echo e($author->getLastName()); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($author->getId()); ?>"><?php echo e($author->getLastName()); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-10 offset-md-2">
                            <?php if(isset($book)): ?>
                                <label for="mySubmit" class="btn btn-primary w-100"><i class="bi bi-floppy2-fill"></i> Save</label>
                                <input id="mySubmit" class="d-none" type="submit" value="Save"/>
                            <?php else: ?>
                                <label for="mySubmit" class="btn btn-primary w-100"><i class="bi bi-floppy2-fill"></i> Create</label>
                                <input id="mySubmit" class="d-none" type="submit" value="Create"/>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-10 offset-md-2">
                            <a class="btn btn-danger w-100" href="<?php echo e(route('book.index')); ?>"><i class="bi bi-box-arrow-left"></i>
                                Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v5_Laravel/resources/views/book/editBook.blade.php ENDPATH**/ ?>