 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', 'Biblios :: Authors\' List'); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Library</li>
<li class="breadcrumb-item active" aria-current="page">Authors</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-6 d-flex justify-content-end">
                <p>
                    <a class="btn btn-success" href="<?php echo e(route('author.create')); ?>">
                        <i class="bi bi-database-add"></i>
                        Create new author</a>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-hover table-responsive">
                    <col width='70%'>
                    <col width='10%'>
                    <col width='10%'>
                    <col width='10%'>
                    <thead>
                        <tr>
                            <th>Author's name</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $authors_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($author->firstname); ?> <?php echo e($author->lastname); ?></td>
                                <td><a class="btn btn-secondary" href="<?php echo e(route('author.show', ['author' => $author->id])); ?>">Details</a></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('author.edit',['author' => $author->id])); ?>"><i class="bi bi-pencil-square"></i> Edit</a></td>
                                <?php if(count($author->books)==0): ?>
                                    <td><a class="btn btn-danger" href="<?php echo e(route('author.destroy.confirm', ['id' => $author->id])); ?>"><i class="bi bi-trash"></i> Delete</a></td>
                                <?php else: ?>
                                    <td><a class="btn btn-secondary" disabled="disabled" href="#"><i class="bi bi-ban"></i> Delete</a></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v7_Middleware/resources/views/author/authors.blade.php ENDPATH**/ ?>