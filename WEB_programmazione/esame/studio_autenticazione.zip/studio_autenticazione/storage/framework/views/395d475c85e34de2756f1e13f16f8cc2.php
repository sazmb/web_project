 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Not implemented</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

<div class="container-fluid text-center">
    <div class="row">
        <div class="col-md-12">
            <div class="card border-danger">
                <div class='card-header'>
                    <b>Not implemented:</b> this functionality has not been implemented yet
                </div>
                <div class='card-body'>
                    <p><img class="img-thumbnail" src="<?php echo e(url('/')); ?>/img/comingSoon.png"></p>
                    <p><a class="btn btn-danger" href="<?php echo e(url()->previous()); ?>"><i class="bi bi-box-arrow-left"></i> Go Back!</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v7_Middleware/resources/views/errors/501.blade.php ENDPATH**/ ?>