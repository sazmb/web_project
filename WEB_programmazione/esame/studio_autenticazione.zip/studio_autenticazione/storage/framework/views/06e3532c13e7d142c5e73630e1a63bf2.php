 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title'); ?>
<?php if(isset($author)): ?>
    Biblios :: Edit Author
<?php else: ?>
    Biblios :: Add new author
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('author.index')); ?>">Library</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('author.index')); ?>">Authors</a></li>
<?php if(isset($author)): ?>
    <li class="breadcrumb-item active" aria-current="page">Edit author</li>
<?php else: ?>
    <li class="breadcrumb-item active" aria-current="page">Add author</li>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <?php if(isset($author)): ?>
                <form name="author" method="post" action="<?php echo e(route('author.update', ['author' => $author->getId()])); ?>">
                <!--<input type="hidden" name="_method" value="PUT">-->
                <?php echo method_field('PUT'); ?>
                <?php else: ?>
                <form class="form-horizontal" name="author" method="post" action="<?php echo e(route('author.store')); ?>">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="title">First Name</label>
                        </div>
                        <div class="col-md-10">
                            <?php if(isset($author)): ?>
                                <input class="form-control" type="text" name="firstName" placeholder="Author's First Name" value="<?php echo e($author->getFirstName()); ?>">
                            <?php else: ?>
                                <input class="form-control" type="text" name="firstName" placeholder="Author's First Name">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-2">
                            <label for="title">Last Name</label>
                        </div>
                        <div class="col-md-10">
                            <?php if(isset($author)): ?>
                                <input class="form-control" type="text" name="lastName" placeholder="Author's Last Name" value="<?php echo e($author->getLastName()); ?>">
                            <?php else: ?>
                                <input class="form-control" type="text" name="lastName" placeholder="Author's Last Name">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-10 offset-md-2">
                            <?php if(isset($author)): ?>
                                <label for="mySubmit" class="btn btn-primary w-100"><i class="bi bi-floppy2-fill"></i> Save</label>
                                <input id="mySubmit" class="d-none" type="submit" value="Save"/>
                            <?php else: ?>
                                <label for="mySubmit" class="btn btn-primary w-100"><i class="bi bi-floppy2-fill"></i> Create</label>
                                <input id="mySubmit" class="d-none" type="submit" value="Create"/>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="col-md-10 offset-md-2">
                            <a class="btn btn-danger w-100" href="<?php echo e(route('author.index')); ?>"><i class="bi bi-box-arrow-left"></i>
                                Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v5_Laravel/resources/views/author/editAuthor.blade.php ENDPATH**/ ?>