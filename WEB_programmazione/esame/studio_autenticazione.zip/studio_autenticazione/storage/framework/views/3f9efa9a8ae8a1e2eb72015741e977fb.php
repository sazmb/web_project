 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', 'Biblios :: Books\' List'); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Library</li>
<li class="breadcrumb-item active" aria-current="page">Books</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-xs-6 d-flex justify-content-end">
            <p>
                <a class="btn btn-success" href="<?php echo e(route('book.create')); ?>">
                    <i class="bi bi-database-add"></i> 
                    Create new book
                </a>
            </p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <col width='50%'>
                <col width='30%'>
                <col width='10%'>
                <col width='10%'>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Author</th>
                        <th></th>
                        <th></th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $books_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($book->getTitle()); ?></td>
                            <td><?php echo e($book->getAuthor()); ?></td>
                            <td>
                                <a class="btn btn-primary" href="<?php echo e(route('book.edit',['book' => $book->getId()])); ?>"><i class="bi bi-pencil-square"></i> Edit</a>
                            </td>
                            <td>
                                <a class="btn btn-danger" href="<?php echo e(route('book.destroy.confirm',['id' => $book->getId()])); ?>"><i class="bi bi-trash"></i> Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v5_Laravel/resources/views/book/books.blade.php ENDPATH**/ ?>