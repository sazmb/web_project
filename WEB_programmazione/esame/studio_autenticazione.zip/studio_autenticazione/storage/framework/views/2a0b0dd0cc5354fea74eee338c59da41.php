 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', __('messages.title')); ?>

<?php $__env->startSection('active_home','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active" aria-current="page">Home</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-lg-9 col-sm-12">
        <div class="citazione">
            <?php if(auth()->check()): ?>
                <h1><?php echo e(__('messages.welcome')); ?>, <?php echo e(auth()->user()->name); ?>!</h1>
                <a class="btn btn-primary" href="<?php echo e(route('hotel.index')); ?>">Accedi alla tua libreria</a>
            <?php else: ?>
                <blockquote>
                    <text> Loggati per accedere alle recensioni Hotel</text>
                </blockquote>
            <?php endif; ?>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samue\Desktop\esame\studio_autenticazione\resources\views/index.blade.php ENDPATH**/ ?>