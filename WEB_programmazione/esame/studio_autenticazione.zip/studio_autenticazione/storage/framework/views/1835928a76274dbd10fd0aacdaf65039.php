 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', 'Biblios :: Author\'s details'); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('author.index')); ?>">Library</a></li>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('author.index')); ?>">Authors</a></li>
<li class="breadcrumb-item active" aria-current="page"><?php echo e($author->firstname); ?> <?php echo e($author->lastname); ?></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-md-10">
        <div class="row mb-3">
            <div class="col-md-3">
                <b>Lastname:</b>
            </div>
            <div class="col-md-9">
                <?php echo e($author->lastname); ?>

            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-3">
                <b>Firstname:</b>
            </div>
            <div class="col-md-9">
                <?php echo e($author->firstname); ?>

            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-3">
                <b>Address:</b>
            </div>
            <div class="col-md-9">
                <?php echo e($author->address->street_and_number); ?> - <?php echo e($author->address->postcode); ?> <?php echo e($author->address->city); ?> (<?php echo e($author->address->province); ?>, <?php echo e($author->address->country); ?>)
            </div>
        </div>
    </div>

    <div class="col-md-2">
        <div class="row mb-3">
            <div class="col-md-12">
                <a class="btn btn-primary w-100" href="<?php echo e(route('author.edit', ['author' => $author->id])); ?>"><i class="bi bi-pencil-square"></i> Edit</a>
            </div>
        </div>

        <div class="row mb-3">
            <div class="col-md-12">
                <?php if(count($author->books)==0): ?>
                    <a class="btn btn-danger w-100" href="<?php echo e(route('author.destroy.confirm', ['id' => $author->id])); ?>"><i class="bi bi-trash"></i> Delete</a>
                <?php else: ?>
                    <a class="btn btn-secondary w-100" disabled="disabled" href="#"><i class="bi bi-ban"></i> Delete</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <a class="btn btn-secondary w-100" href="<?php echo e(route('author.index')); ?>"><i class="bi bi-box-arrow-left"></i> Back</a>
    </div>
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v6-plus_Eloquent/resources/views/author/details.blade.php ENDPATH**/ ?>