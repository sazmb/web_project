 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', 'Biblios :: Authors\' List'); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Library</li>
<li class="breadcrumb-item active" aria-current="page">Authors</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<script>
    $(document).ready(function(){
        // Searching feature
        $("#searchInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();

            // Reimposta completamente la paginazione se il campo di ricerca viene svuotato
            if (value !== "") {
                $("#paginationNav").hide();
            } else {
                $("#paginationNav").show();
                currentPage = 1; // Riporta alla prima pagina
                return;
            }

            var column = $("#searchInput").attr("data-column");

            $("#authorTable tbody tr").each(function() {
                var found = false;
                
                $(this).find("td").slice(0, -3).each(function() { // Escludi le ultime tre colonne
                    var text = $(this).text().toLowerCase();
                    if (text.indexOf(value) > -1) {
                        found = true;
                    }
                });
                $(this).toggle(found);
            });
        });
    });
</script>

    <div class="container-fluid">
        <div class="row">
            <div class="input-group mb-3">
                <input type="text" id="searchInput" class="form-control" aria-label="Text input" placeholder="Search...">
            </div>
        </div>

        <nav aria-label="Page navigation example" id="paginationNav">
            <ul class="pagination justify-content-center">
                <li class="page-item" id="previousPage"><a class="page-link" href="#">Previous</a></li>
                <!-- Numeri di pagina -->
                <li class="page-item" id="nextPage"><a class="page-link" href="#">Next</a></li>
                <li>
                    <select id="rowsPerPage" class="form-control justify-content-end">
                        <option value="5">5 authors per page</option>
                        <option value="10">10 authors per page</option>
                        <option value="15">15 authors per page</option>
                        <option value="20">20 authors per page</option>
                    </select>
                </li>
            </ul>
        </nav>

        <div class="row">
            <div class="col-xs-6 d-flex justify-content-end">
                <p>
                    <a class="btn btn-success" href="<?php echo e(route('author.create')); ?>">
                        <i class="bi bi-database-add"></i>
                        Create new author</a>
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <table id="authorTable" class="table table-striped table-hover table-responsive">
                    <col width='70%'>
                    <col width='10%'>
                    <col width='10%'>
                    <col width='10%'>
                    <thead>
                        <tr>
                            <th>Author's name</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $authors_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($author->firstname); ?> <?php echo e($author->lastname); ?></td>
                                <td><a class="btn btn-secondary" href="<?php echo e(route('author.show', ['author' => $author->id])); ?>">Details</a></td>
                                <td><a class="btn btn-primary" href="<?php echo e(route('author.edit',['author' => $author->id])); ?>"><i class="bi bi-pencil-square"></i> Edit</a></td>
                                <?php if(count($author->books)==0): ?>
                                    <td><a class="btn btn-danger" href="<?php echo e(route('author.destroy.confirm', ['id' => $author->id])); ?>"><i class="bi bi-trash"></i> Delete</a></td>
                                <?php else: ?>
                                    <td><a class="btn btn-secondary" disabled="disabled" href="#"><i class="bi bi-ban"></i> Delete</a></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\samue\Desktop\WEB_programmazione\tde_svolti\06_Carica_pdf\studio_autenticazione\resources\views/author/authors.blade.php ENDPATH**/ ?>