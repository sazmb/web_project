 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', 'Biblios :: Authors\' List'); ?>

<?php $__env->startSection('active_MyLibrary','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('home')); ?>">Home</a></li>
<li class="breadcrumb-item active" aria-current="page">Library</li>
<li class="breadcrumb-item active" aria-current="page">Authors</li>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/devis/Library/CloudStorage/GoogleDrive-devis.bianchini@unibs.it/Il mio Drive/_Cloud/Didattica/MaterialeDidattico/PW/Esercizi_esempi/2024.2025/RunningExample_Books/PW_runningExample_v5_Laravel/resources/views/author/authors.blade.php ENDPATH**/ ?>