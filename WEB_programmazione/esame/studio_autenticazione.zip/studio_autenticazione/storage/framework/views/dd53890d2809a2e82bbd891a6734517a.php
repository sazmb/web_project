 <!-- title - active_home - active_MyLibrary - breadcrumb - body -->

<?php $__env->startSection('title', __('messages.title')); ?>

<?php $__env->startSection('active_home','active'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active" aria-current="page">Home</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<div class="row">
    <div class="col-lg-9 col-sm-12">
        <div class="citazione">
            <p><?php echo e($content); ?>

            </p>
            <blockquote>
                <p><?php echo e(trans('messages.proverb')); ?> </p>
                <small>[<?php echo e(trans('messages.citation')); ?>]</small>
            </blockquote>
        </div>
    </div>

    <div class="col-lg-3 col-sm-12">
        <div class="imgBiblio">
            <img class="img-thumbnail img-responsive" src="<?php echo e(url('/')); ?>/img/pretty-4-th.jpg">
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/PW_runningExample_v9_internazionalizzazione/resources/views/index.blade.php ENDPATH**/ ?>